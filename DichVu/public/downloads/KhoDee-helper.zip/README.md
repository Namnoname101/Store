# DaiTruong OneClick 2.0 (Native GUI)

Standalone Windows x64 configuration assistant for Codex CLI and ModelAPI.

## Features
- **Pure Native Win32/WPF Executable**: No PowerShell console, no `.ps1` or `.cmd` dependencies.
- **Dedicated Application Identity**: Ships with custom `DaiTruong.ico` embedded directly into the PE header and window, assigned with a unique `AppUserModelID` for clean Taskbar grouping.
- **Dark Glassmorphism Interface**: Modern, responsive dark UI matching the official DaiTruong Store design system.
- **Zero Configuration Setup**: Pre-embeds the tested `EXACT_config.toml` (gpt-6.1-sol, responses wire_api, 1M context).
- **Environment Auto-Detection**: Automatically finds Codex CLI in PATH and standard directories. Offers a 1-click installer via `npm` if Codex CLI is missing.
- **High Security**: Restricts `%USERPROFILE%\.codex\auth.json` permissions to the current Windows user SID via Windows Access Control Lists (ACL).

## How to Build from Source
Compile using the built-in Windows .NET Framework 4.8 compiler:
```powershell
csc.exe /target:winexe /win32icon:DaiTruong.ico /resource:DaiTruong.ico /lib:"C:\Windows\Microsoft.NET\Framework64\v4.0.30319\WPF" /r:PresentationCore.dll,PresentationFramework.dll,WindowsBase.dll,System.Xaml.dll,System.dll,System.Core.dll /optimize /out:"DaiTruong OneClick.exe" "DaiTruongOneClick.cs"
```
